package cmps312.qu.edu.qa.woqodqatar;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private Button calculateCost, summaries;
    private String woqodUrl = "http://www.woqod.com/EN/Gas/Pages/Fuel-Price.aspx";
    private String fuelType = "WOQODPetrolType";
    private String diesel = "Diesel";


    private String FuelPrice = "xPortalPriceOWSNMBR";
    private TextView textViewDiesel,textView91,textView95,textViewDieselValue,textView91Value,textView95Value;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        calculateCost = (Button) findViewById(R.id.calculate_cost);
        textViewDiesel = (TextView) findViewById(R.id.diesel_name);
        textView91 = (TextView) findViewById(R.id.gasoline91_name);
        textView91Value = (TextView) findViewById(R.id.g91_value);
        textView95 = (TextView)findViewById(R.id.gasoline91_name);
        textView95Value = (TextView) findViewById(R.id.g95_value);
        ReadDataThread dataThread= new ReadDataThread();
        dataThread.execute(woqodUrl);
        summaries = (Button) findViewById(R.id.summaries);

        summaries.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent goToSummaries = new Intent(MainActivity.this,SummariesActivity.class);
                startActivity(goToSummaries);
            }
        });

        calculateCost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //go to calculate cost
            }
        });
    }


    private class ReadDataThread extends AsyncTask<String,Void,ArrayList<ExtractData>>{
        HttpURLConnection connection;
        ArrayList<ExtractData> data = new ArrayList<>();
        InputStream inputStream;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Toast.makeText(MainActivity.this,"Uploading data. . .",Toast.LENGTH_LONG).show();
        }

        @Override
        protected ArrayList<ExtractData> doInBackground(String... urls) {


            try {
                connection = (HttpURLConnection) new URL(urls[0]).openConnection();
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(3000);

                inputStream = new BufferedInputStream(connection.getInputStream());

                data = extractInfoFromWoqod(inputStream);

            }catch (Exception e){
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(ArrayList<ExtractData> extractData) {
            super.onPostExecute(extractData);
        }
    }


    private ArrayList<ExtractData> extractInfoFromWoqod(InputStream inputStream) throws Exception{

        ArrayList<ExtractData> extractData = new ArrayList<>(3);
        String type =null,price = null;
        BufferedInputStream bis = new BufferedInputStream(inputStream);
        BufferedReader br = new BufferedReader(new InputStreamReader(bis));
        String data;

        try {
            while ((data = br.readLine()) != null) {
                if(data.contains(fuelType)){
                    type = data.substring(data.indexOf(":")+1,data.lastIndexOf("\""));
                }else if(data.contains(FuelPrice)){
                    price = data.substring(data.indexOf(":")+1,data.lastIndexOf("\""));
                }


            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        extractData.add(new ExtractData(type,Double.parseDouble(price)));
        //textViewDiesel.setText(extractData.get(0).toString());
        //textViewDieselValue.setText(extractData.get(1).);

        for(int i=0;i<extractData.size();i++){
            textViewDiesel.setText(i+"");
            textViewDieselValue.setText(i+"");
        }
        return  extractData;
    }


    private String convertToString(InputStream inputStream) {

        BufferedInputStream bis = new BufferedInputStream(inputStream);
        BufferedReader br = new BufferedReader(new InputStreamReader(bis));
        StringBuilder sp = new StringBuilder();
        String line;


        try {
            while ((line = br.readLine()) != null) {
                sp.append(line);

            }
        } catch (IOException e) {
            e.printStackTrace();
        }


        return sp.toString();
    }
}
