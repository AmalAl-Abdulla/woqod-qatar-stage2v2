package cmps312.qu.edu.qa.woqodqatar;

/**
 * Created by mooli_000 on 12/17/2017.
 */

public class ExtractData {
    //extract fuel name and price from xml

    private String fuelType;
    private double fuelPrice;


    public ExtractData(String fuelType, double fuelPrice) {
        this.fuelType = fuelType;
        this.fuelPrice = fuelPrice;
    }

    public ExtractData() {
    }


    public String getFuelType() {
        return fuelType;
    }

    public void setFuelType(String fuelType) {
        this.fuelType = fuelType;
    }

    public double getFuelPrice() {
        return fuelPrice;
    }

    public void setFuelPrice(double fuelPrice) {
        this.fuelPrice = fuelPrice;
    }
}
