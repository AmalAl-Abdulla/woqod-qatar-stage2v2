package cmps312.qu.edu.qa.woqodqatar;


import android.text.format.DateFormat;

import java.util.Calendar;
import java.util.Date;

/**
 * Created by mooli_000 on 12/15/2017.
 */

public class UserSummary {
    private Calendar calendar = Calendar.getInstance();
    private String fuelType;
    private double price;
    private Date date;
    private double fuelAmount;
    private String station;

    public UserSummary() {
    }

    public UserSummary(String fuelType, double price, double fuelAmount, String station) {// date is auto generated
        this.fuelType = fuelType;
        this.price = price;
        this.date = new Date(calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH));
        this.fuelAmount = fuelAmount;
        this.station = station;
    }

    public String getFuelType() {
        return fuelType;
    }

    public void setFuelType(String fuelType) {
        this.fuelType = fuelType;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public double getFuelAmount() {
        return fuelAmount;
    }

    public void setFuelAmount(double fuelAmount) {
        this.fuelAmount = fuelAmount;
    }

    public String getStation() {
        return station;
    }

    public void setStation(String station) {
        this.station = station;
    }
}
